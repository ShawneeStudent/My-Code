#pragma once

#include "ImageTexture2DArray.h"
#include "Buffer.h"
#include "Program.h"
#include "math3d.h"
#include "glfuncs.h"


class Mesh{
public:

    class Material{
    public:
        std::string name;
        vec3 diffuse;
        vec3 specular;
        float shininess;
        std::shared_ptr<Texture> tex;
        std::shared_ptr<Texture> etex;
        int start;  //in bytes
        int count;  //in indices
    };
    
    std::map<std::string,Material> materialDict;
    std::vector<Material> materials;
    
    GLuint vao;
    
    Mesh(std::string fname){
        
        std::ifstream in("assets/"+fname);
        if( !in.good() )
            throw std::runtime_error("Cannot open assets/"+fname);
            
        std::vector<vec3> fpos;
        std::vector<vec3> fnorm;
        std::vector<vec2> ftex;
        std::string currmtl;
        typedef std::array<int,3> Vertex;
        std::map<std::string, std::vector<Vertex> > faces;

        while(true){
            std::string line;
            getline(in,line);
            if( in.fail() )
                break;
            std::istringstream iss(line);
            std::string word;
            iss >> word;
            if( iss.fail() )
                continue;
            if( word.find('#') == 0 ){
            } else if( word == "v" ){
                float x,y,z;
                iss >> x >> y >> z;
                fpos.push_back(vec3(x,y,z));
            } else if( word == "vn" ){
                float x,y,z;
                iss >> x >> y >> z;
                fnorm.push_back(vec3(x,y,z));
            } else if( word == "vt" ){
                float x,y;
                iss >> x >> y;
                ftex.push_back(vec2(x,y));
            } else if( word == "f" ){
                std::vector<std::string> lst;
                while(1){
                    std::string tmp;
                    iss >> tmp;
                    if( iss.fail() )
                        break;
                    lst.push_back(tmp);
                }
                if(lst.size() != 3 ){
                    std::cout << "Non-triangle: ";
                    for(auto q : lst ){
                        std::cout << q << " ";
                    }
                    std::cout << "\n";
                    throw std::runtime_error("Non-triangle in file " + fname + ": "+std::to_string(lst.size()) );
                } else {
                    for(std::string vspec : lst ){
                        char slash;
                        int vi,ti,ni;
                        std::istringstream iss(vspec);
                        iss >> vi >> slash >> ti >> slash >> ni;
                        if( iss.fail() )
                            throw std::runtime_error("Missing tex or normal in "+fname);
                        vi-=1;
                        ti-=1;
                        ni-=1;
                        faces[currmtl].push_back( Vertex{vi,ti,ni} );
                    }
                }
            } else if( word == "mtllib" ){
                std::string mfile;
                getline(iss,mfile);
                parseMtlFile(trim(mfile));
            } else if( word == "usemtl" ){
                iss >> currmtl;
            }
        }
        
        std::vector<float> vdata, tdata, ndata;
        std::vector<uint32_t> idata;
        std::map<Vertex,unsigned> vmap;
        unsigned numv=0;
        
        for(auto& it : faces ){
            std::string mname = it.first;
            materialDict[mname].start = idata.size()*4;    //in bytes
            materialDict[mname].count = 0;
            for( Vertex v : it.second ){
                if( vmap.find(v) == vmap.end() ){
                    vmap[v] = numv;
                    int vi = v[0];
                    int ti = v[1];
                    int ni = v[2];
                    vdata.push_back(fpos[vi].x);
                    vdata.push_back(fpos[vi].y);
                    vdata.push_back(fpos[vi].z);
                    ndata.push_back(fnorm[ni].x);
                    ndata.push_back(fnorm[ni].y);
                    ndata.push_back(fnorm[ni].z);
                    tdata.push_back(ftex[ti].x);
                    tdata.push_back(ftex[ti].y);
                    numv+=1;
                }
                idata.push_back( vmap[v] );
                materialDict[mname].count++;       //in integers
            }
        }
        
        for( auto& it : materialDict ){
            Material& m = it.second;
            if( m.count > 0 ){
                if( !m.tex )
                    m.tex = std::make_shared<ImageTexture2DArray>("white.png");
                if( !m.etex )
                    m.etex = std::make_shared<ImageTexture2DArray>("black.png");
                materials.push_back( it.second );
            }
        }
        
        std::shared_ptr<Buffer> pbuff = std::make_shared< Buffer >( vdata  );
        std::shared_ptr<Buffer> nbuff = std::make_shared< Buffer >( ndata  );
        std::shared_ptr<Buffer> tbuff = std::make_shared< Buffer >( tdata  );
        std::shared_ptr<Buffer> ibuff = std::make_shared< Buffer >( idata  );
        
        GLuint tmp[1];
        glGenVertexArrays(1,tmp);
        vao = tmp[0];
        glBindVertexArray(vao);
        ibuff->bind(GL_ELEMENT_ARRAY_BUFFER);
        
        pbuff->bind(GL_ARRAY_BUFFER);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer( 0, 3, GL_FLOAT, false, 3*4, 0 );
        
        tbuff->bind(GL_ARRAY_BUFFER);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer( 1, 2, GL_FLOAT, false, 2*4, 0 );
        
        nbuff->bind(GL_ARRAY_BUFFER);
        glEnableVertexAttribArray(2);
        glVertexAttribPointer( 2, 3, GL_FLOAT, false, 3*4, 0 );

        glBindVertexArray(0);
        this->vao = vao;
    }
    
    void parseMtlFile(std::string fname){
        std::ifstream in("assets/"+fname);
        if(!in.good() )
            throw std::runtime_error("Cannot open assets/"+fname);
        
        std::string currmtl;

        while(1){
            std::string line;
            std::getline(in,line);
            if( in.fail() )
                break;
            std::istringstream iss(line);
            std::string key;
            iss >> key;
            if( iss.fail() )
                continue;
            if( key[0] == '#' )
                continue;
            if(key == "newmtl"){
                iss >> currmtl;
                this->materialDict[currmtl].name = currmtl;
            } else if(key == "Kd"){
                iss >> this->materialDict[currmtl].diffuse.x;
                iss >> this->materialDict[currmtl].diffuse.y;
                iss >> this->materialDict[currmtl].diffuse.z;
            } else if( key == "Ks"){
                iss >> this->materialDict[currmtl].specular.x;
                iss >> this->materialDict[currmtl].specular.y;
                iss >> this->materialDict[currmtl].specular.z;
            } else if( key == "Ns"){
                iss >> this->materialDict[currmtl].shininess;
            }else if( key == "map_Kd" ){
                std::string pth;
                getline(iss,pth);
                this->materialDict[currmtl].tex = loadTexture(trim(pth));
            }
            else if( key == "map_Ke" ){
                std::string pth;
                getline(iss,pth);
                this->materialDict[currmtl].etex = loadTexture(trim(pth));
            }
        }
    }
    
    std::shared_ptr<ImageTexture2DArray> loadTexture(std::string pth){
        if( pth[0] == '/' || pth.find(":") != std::string::npos ){
            throw std::runtime_error("Texture uses absolute path: "+pth);
        }
        if( pth.find("..") != std::string::npos ){
            throw std::runtime_error(".. in path");
        }
        return std::make_shared<ImageTexture2DArray>(pth);
    }
    
    void draw(){
        glBindVertexArray(this->vao);
        for(auto& m : materials ){
            Program::setUniform("diffuse",m.diffuse);
            Program::setUniform("specular",m.specular);
            Program::setUniform("shininess",m.shininess);
            Program::updateUniforms();
            m.tex->bind(0);
            m.etex->bind(1);
            glDrawElements(GL_TRIANGLES, m.count, GL_UNSIGNED_INT, ((char*)0) + m.start );
        }
    }
};
