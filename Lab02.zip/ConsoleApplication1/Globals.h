#pragma once 

#include "utils.h"
#include "Stars.h"
#include "Hero.h"
#include "Mesh.h"
#include "Text.h"
#include "Enemy.h"
#include "Powerup.h"
#include "PowerupManager.h"


class Globals {
    public:
    
    Mix_Chunk* pewSound{ Mix_LoadWAV("assets/pew.ogg") };
    Mix_Chunk* bigPewSound{ Mix_LoadWAV("assets/bigpew.ogg") };
    Mix_Chunk* hitSound{ Mix_LoadWAV("assets/hit2.ogg") };
    
    Stars stars{100};
    Program starProg{"starvs.txt","starfs.txt"};
    Program mainProg{"vs.txt","fs.txt"};
    Program skyboxProg{"skyboxvs.txt","skyboxfs.txt"};
    Sampler sampler;
    Hero hero{vec3(-0.8f,0,0)};
    Mesh skybox{"cube.obj"};
    Text chargeText{"consolefont",12};
    Camera camera{vec3(0,0,3), vec3(0,0,0), vec3(0,1,0) };
    Mesh asteroidMesh{"asteroid.obj"};
    
    std::set<int> keyset;

    std::vector<vec3> asteroids ;
    std::vector<std::shared_ptr<Enemy> > enemies;
    std::vector<std::shared_ptr<Bullet>> bullets ;

	std::vector<std::shared_ptr<Powerup>> powerups;


	PowerupManager powerUpManager = PowerupManager();


    bool paused=false;
    int timeToNextSpawn = 1000;
    float bulletCharge = 0.0f;
};
