#include "utils.h"
#include "Mesh.h"
#include "Program.h"
#include "StraightLineEnemy.h"
#include "Bullet.h"
#include "Hero.h"
#include "Jellyfish.h"
#include "Text.h"
#include "Powerup.h"
#include "PowerupManager.h"

const vec3 Ship::deathAxis = normalize(vec3(1,1,1));


std::shared_ptr<Mesh>                       Bullet::            mesh;
std::shared_ptr<Mesh>                       Hero::              mesh;
std::shared_ptr<Mesh>                       Jellyfish::         mesh;
std::map<std::string,std::array<int,4> >    Program::           uniforms;
Program*                                    Program::           current;
std::shared_ptr<Buffer>                     Program::           uboBuffer;
std::vector<char>                           Program::           uboBackingMemory;
std::shared_ptr<Mesh>                       StraightLineEnemy:: mesh;
std::shared_ptr<Program>                    Text::              prog;
std::shared_ptr<Mesh>						Powerup::			mesh;		

std::shared_ptr<Program>                    PowerupManager::	prog;
