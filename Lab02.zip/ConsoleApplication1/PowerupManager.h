#pragma once

#include "utils.h"

class PowerupManager {
public:
	std::vector<vec3> pos;
	bool dirty = false;
	static std::shared_ptr<Program> prog;
	GLuint vao;
	std::shared_ptr<Buffer> pbuff;

	/**
	*/
	PowerupManager() {
		if (prog == nullptr) {
			prog = std::make_shared<Program>("bbvs.txt", "bbgs.txt", "bbfs.txt");
		}
		pbuff = std::make_shared< Buffer >(4, GL_DYNAMIC_DRAW);
		GLuint tmp[1];
		glGenVertexArrays(1, tmp);
		vao = tmp[0];
		glBindVertexArray(vao);
		pbuff->bind(GL_ARRAY_BUFFER);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, false, 3 * 4, 0);
		glBindVertexArray(0);
		
	}

	/** Add a new powerup to the set of powerups managed by this manager.
		@param p The location of the powerup to add
	*/

	void add(vec3 p) {
		pos.push_back(p);    //push p to the back of pos
		dirty = true;       //set dirty to true
	}

	void update(int elapsed) {
	}

	void draw() {
		if (dirty) {                                          //check if dirty
			pbuff->update(pos, GL_DYNAMIC_DRAW);             //update pbuff
			dirty = false;                                  //make dirty false
		}
		auto current = Program::current;                    //set current to Program::current
		prog->use();
		glBindVertexArray(vao);
		glDrawArrays(GL_POINTS, 0, pos.size());
		if (current)
			current->use();
	}



};