#pragma once
#include "utils.h"
#include "Mesh.h"


class Powerup {
public:
	static constexpr float BULLET_RADIUS = 0.05f;
	vec3 position;
	int state = ALIVE;
	vec3 velocity;
	static std::shared_ptr<Mesh> mesh;
	float texFrame = 0;

	Powerup(vec3 pos) {
		this->position = pos;
		if (mesh == nullptr)
			mesh = std::make_shared<Mesh>("bullet.obj");
	}

	void update(int elapsed, Hero hero) {

		if (this->collidesWith(hero))
		{
			this->state = DEAD;
		}

	}

	void draw() {
		Program::setUniform("worldMatrix", translation(this->position));
		Program::setUniform("texSlice", (this->texFrame));
		mesh->draw();
	}

	//template<typename T>
	bool collidesWith(Hero hero) {
		if (this->state != ALIVE or hero.state != ALIVE)
			return false;
		return ::collidesWith(
			this->position, BULLET_RADIUS,
			hero.position, hero.radius);
	}
};


