out vec4 color;
layout(binding=0) uniform sampler2DArray tex;
in vec2 g_texcoord;
void main(){
	color = texture( tex, vec3(g_texcoord,texSlice) );
	if( color.a < 0.01 )
		discard;
}
