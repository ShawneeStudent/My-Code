#!/usr/bin/env python3

import tkinter.filedialog
import sys
import os.path
import array 

class Material:
    def __init__(self):
        self.diffuse = (1,1,1)
        self.texfile=None
        self.etexfile=None
        
def convert(fname):
    print("Converting",fname)
    fpos=[]
    ftex=[]
    fnorm=[]
    faces={}
    materials={}
    
    pfx = os.path.dirname(fname)
    
    bbmin = [1E99,1E99,1E99]
    bbmax = [-1E99,-1E99,-1E99]
    
    with open(fname) as fp:
        for line in fp:
            line = line.strip()
            lst = line.split()
            if len(line) == 0:
                continue
            elif line[0] == '#':
                continue
            elif lst[0] == "v":
                x,y,z = [float(q) for q in lst[1:]]
                fpos.append( (x,y,z) )
                if x < bbmin[0]: bbmin[0] = x
                if y < bbmin[1]: bbmin[1] = y
                if z < bbmin[2]: bbmin[2] = z
                if x > bbmax[0]: bbmax[0] = x
                if y > bbmax[1]: bbmax[1] = y
                if z > bbmax[2]: bbmax[2] = z
            elif lst[0] == "vn":
                x,y,z = [float(q) for q in lst[1:]]
                fnorm.append( (x,y,z) )
            elif lst[0] == "vt":
                x,y = [float(q) for q in lst[1:]]
                ftex.append( (x,y) )
            elif lst[0] == "f":
                if len(lst) != 4:
                    print("Non-triangle in file")
                else:
                    if currmtl not in faces:
                        faces[currmtl]=[]
                    for vspec in lst[1:]:
                        tmp = vspec.split("/")
                        tmp = [int(q) for q in tmp]
                        if len(tmp) != 3:
                            print("Missing tex or normal")
                        else:
                            vi,ti,ni = tmp
                        vi-=1
                        ti-=1
                        ni-=1
                        faces[currmtl].append( (vi,ti,ni) )
            elif lst[0] == "mtllib":
                parseMtl(pfx,materials,lst[1])
            elif lst[0] == "usemtl":
                currmtl = lst[1]
    
    numv=0
    vdata = []
    tdata = []
    ndata = []
    numi=0
    idata = []
    vmap = {}
    mmap = {}
    
    for mname in faces:
        for vi,ti,ni in faces[mname]:
            if mname not in mmap:
                mmap[mname]=[numi,0]
            key = vi,ti,ni
            if key not in vmap:
                vmap[key]=numv
                vdata += fpos[vi]
                tdata += ftex[ti]
                ndata += fnorm[ni]
                numv+=1
            idata.append( vmap[key] )
            mmap[mname][1] += 1
            numi+=1

    with open(fname+".mesh","wb") as fp:
        fp.write(b"mesh 2\n")
        fp.write(b"bbox %f %f %f %f %f %f\n" % (bbmin[0],bbmin[1],bbmin[2],
            bbmax[0],bbmax[1],bbmax[2]))
        fp.write(b"materials %d\n" % len(list(mmap.keys())) )
        for mname in materials:
            if mmap[mname][1] == 0:
                continue
            M=materials[mname]
            fp.write( b"material %s\n" % mname.encode())
            fp.write( b"diffuse %s\n" % M.diffuse.encode())
            fp.write( b"specular %s\n" % M.specular.encode())
            fp.write( b"shininess %s\n" % M.shininess.encode())
            if M.texfile == None:
                fp.write( b"texfile white.png\n")
            else:
                fp.write( b"texfile %s\n" % M.texfile.encode())
            if M.etexfile == None:
                fp.write( b"etexfile black.png\n")
            else:
                fp.write( b"etexfile %s\n" % M.etexfile.encode())
            #start is in bytes, count is in ints
            fp.write( b"range %d %d\n" % (mmap[mname][0]*4, mmap[mname][1]) )
            
        A=array.array("f",vdata)
        B=A.tobytes()
        fp.write(b"positions %d\n" % len(B))
        fp.write(B)
        fp.write(b"\n")
        
        A=array.array("f",tdata)
        B=A.tobytes()
        fp.write(b"texCoords %d\n" % len(B))
        fp.write(B)
        fp.write(b"\n")

        A=array.array("f",ndata)
        B=A.tobytes()
        fp.write(b"normals %d\n" % len(B))
        fp.write(B)
        fp.write(b"\n")
        
        A=array.array("I",idata)
        B=A.tobytes()
        fp.write(b"indices %d\n" % len(B))
        fp.write(B)
        fp.write(b"\n")
        
        fp.write(b"end\n")
                
def parseMtl(pfx,materials,fname):
    with open(os.path.join(pfx,fname) ) as fp:
        for line in fp:
            line = line.strip()
            if len(line) == 0:
                continue
            if line.startswith("#"):
                continue
                
            key,value = line.split(" ",1)
            if key == "newmtl":
                currmtl = value
                materials[currmtl] = Material()
            elif key == "Kd":
                materials[currmtl].diffuse = value
            elif key == "Ks":
                materials[currmtl].specular = value
            elif key == "Ns":
                materials[currmtl].shininess = value
            elif key == "map_Kd":
                if os.path.isabs(value):
                    raise RuntimeError("Texture uses absolute path: "+value)
                if ".." in value:
                    raise RuntimeError(".. in path")
                materials[currmtl].texfile = value
            elif key == "map_Ke":
                if os.path.isabs(value):
                    raise RuntimeError("Texture uses absolute path: "+value)
                if ".." in value:
                    raise RuntimeError(".. in path")
                materials[currmtl].etexfile = value
                
                
                            

if len(sys.argv) > 1:
    infiles = sys.argv[1:]
else:
    infiles = tkinter.filedialog.askopenfilenames( initialdir=".", filetypes=( ("OBJ files","*.obj"), ("All files","*.*")))
           
for x in infiles: 
    convert(x)
 
